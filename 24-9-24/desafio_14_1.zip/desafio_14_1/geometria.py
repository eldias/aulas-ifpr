import math

def area_quadrado(lado):
    area = lado * lado
    return lado

def area_triangulo(base, altura):
    area = (base * altura) / 2
    return area

def area_retangulo(base, altura):
    area = base * altura
    return area

def area_circulo(raio):
    area = math.pi * raio ** 2
    return area