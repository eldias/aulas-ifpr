import geometria as geo

print("Calcular area")
print("1 - Quadrado")
print("2 - Triangulo")
print("3 - Retângulo")
print("4 - Círculo")

opcao = int(input("Qual a opção escolhida? "))

if opcao == 1:
    lado = float(input("qual o lado? "))
    area = geo.area_quadrado(lado)
elif opcao == 2:
    base = float(input("Qual a base? "))
    altura = float(input("Qual a altura"))
    area = geo.area_triangulo(base, altura)
elif opcao == 3:
    base = float(input("Qual a base? "))
    altura = float(input("Qual a altura? "))
    area = geo.area_retangulo(base, altura)
elif opcao == 4:
    raio = float(input("Qual o raio? "))
    area = geo.area_circulo(raio)

print(f"{area:.2f}")