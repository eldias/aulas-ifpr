from distancia import distancia_km, distancia_mi

print("Converter distâncias:")
print("1 - Converter KMs em milhas")
print("2 - Converter Milhas em KMs")

opcao = int(input("Qual a opção escolhida? "))

if opcao == 1:
    milhas = float(input("Qual a distância em milhas a serem convertidas? "))
    distancia = distancia_km(milhas)
    print(f"A distância convertida é de {distancia:.2f} Kms")
elif opcao == 2:
    kms = float(input("Qual a distância em quilometros a serem convertidas? "))
    distancia = distancia_mi(kms)
    print(f"A distância convertida é de {distancia:.2f} Milhas")

