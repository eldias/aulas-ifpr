def distancia_km(milhas):
    dist_km = 0.6214 * milhas
    return dist_km

def distancia_mi(kms):
    dist_mi = 1.6093 * kms
    return dist_mi