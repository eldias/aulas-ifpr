"""
    • Permutação, arranjo e combinação são calculadas a partir do fatorial
        • Permutação de n = n!
        • Arranjo de n em k = n! / (n-k)!
        • Combinação de n em k = n! / (k!(n-k)!)

"""

from math import factorial

def permutacao(n):
    resultado = factorial(n)
    return resultado

def arranjo(n, k):
    return factorial(n) // factorial(n - k)

def combinacoes(n, k):
    return factorial(n) // (factorial(k) * factorial(n - k))