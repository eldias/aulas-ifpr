from analise_combinatoria import permutacao, arranjo, combinacoes

print("Funções de Análise Combinatória:")
print("1 - Permutação:")
print("2 - Arranjo:")
print("3 - Combinação:")

opcao = int(input("Qual a opção escolhida? "))

if opcao == 1:
    n = int(input("\nQual a quantidade de elementos a calcular (n)? "))
    numero = permutacao(n)
    print(f"\nA quantidade de variações possíveis é de: {numero}")
    
elif opcao == 2:
    n = int(input("\nQual o número total de (n)? "))
    k = int(input("\nQual o número selecionado de (k)? "))
    numero = arranjo(n, k)
    print(f"\nA quantidade de variações possíveis é de: {numero}")


elif opcao == 3:
    n = int(input("\nQual o número total de (n)? "))
    k = int(input("\nQual o número selecionado de (k)? "))
    numero = combinacoes(n, k)
    print(f"\nA quantidade de variações possíveis é de: {numero}")